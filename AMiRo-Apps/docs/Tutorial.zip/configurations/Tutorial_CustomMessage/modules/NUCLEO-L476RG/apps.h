#ifndef APPS_H
#define APPS_H

#include <urt.h>

#if defined(__cplusplus)
extern "C" {
#endif
void appsInit(void);
#if defined(__cplusplus)
}
#endif

#endif
