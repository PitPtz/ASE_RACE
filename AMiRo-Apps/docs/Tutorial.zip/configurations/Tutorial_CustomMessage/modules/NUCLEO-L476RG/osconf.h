#ifndef OSCONF_H
#define OSCONF_H

#define AMIROOS_CFG_MAIN_EXTRA_INCLUDE_HEADER apps.h

#define AMIROOS_CFG_MAIN_INIT_HOOK_2() \
  urtCoreInit(NULL);                   \
  appsInit();

#define AMIROOS_CFG_MAIN_INIT_HOOK_3() \
  urtCoreStartNodes();

#define AMIROOS_CFG_MAIN_SHUTDOWN_HOOK_1() \
  urtCoreStopNodes(URT_STATUS_OK);

#endif
