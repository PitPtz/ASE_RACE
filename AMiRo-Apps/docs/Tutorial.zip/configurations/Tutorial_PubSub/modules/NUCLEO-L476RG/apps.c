#include <apps.h>

#include <tutorial.h>
#include <stdlib.h>

#define STOPEVENT (1 << 8)

#define TOPICID   1

aos_timer_t triggertimer;
aos_timer_t terminationtimer;
urt_osEventSource_t triggerSource;
urt_osEventSource_t terminationSource;

struct tutorial_master master;
struct tutorial_slave slave;

urt_topic_t topic;

static void triggercb(virtual_timer_t* timer, void* flags)
{
  (void)timer;
  chEvtBroadcastFlagsI(&triggerSource, (urt_osEventFlags_t)flags);
  return;
}

static void terminationcb(virtual_timer_t* timer, void* params)
{
  (void)timer;
  (void)params;
  aosTimerResetI(&triggertimer);
  chEvtBroadcastI(&terminationSource);
  return;
}

int shellcb(BaseSequentialStream* stream, int argc, const char* argv[], urt_osEventFlags_t flags) {
  (void)stream;
  (void)argc;

  // parse arguments
  aos_longinterval_t duration = atof(argv[1]) * MICROSECONDS_PER_SECOND + 0.5f;
  aos_longinterval_t period = (1.0f / atof(argv[2])) * MICROSECONDS_PER_SECOND + 0.5f;

  // register to execution event
  event_listener_t listener;
  aosShellEventRegisterMask(&terminationSource, &listener, STOPEVENT);

  // activate the timers
  aosTimerPeriodicLongInterval(&triggertimer, period, triggercb, (void*)flags);
  aosTimerSetLongInterval(&terminationtimer, duration, terminationcb, NULL);

  // wait for the execution to finish and unregister from execution event
  chEvtWaitOne(STOPEVENT);
  aosShellEventUnregister(&terminationSource, &listener);

  // sleep until all output is printed
  aosThdMSleep(100);

  return AOS_OK;
}

static int shellcb_message(BaseSequentialStream* stream, int argc, const char* argv[]) {
  return shellcb(stream, argc, argv, TRIGGERFLAG_MESSAGE);
}
static AOS_SHELL_COMMAND(shellcmd_message, "Tutorial:PeriodicOutput", shellcb_message);

static int shellcb_pubsub(BaseSequentialStream* stream, int argc, const char* argv[]) {
  return shellcb(stream, argc, argv, TRIGGERFLAG_PUBSUB);
}
static AOS_SHELL_COMMAND(shellcmd_pubsub, "Tutorial:PubSub", shellcb_pubsub);

void appsInit(void) {
  // initialize timers and event sources
  aosTimerInit(&triggertimer);
  aosTimerInit(&terminationtimer);
  urtEventSourceInit(&triggerSource);
  urtEventSourceInit(&terminationSource);

  // initialize publish-subscribe data
  urtTopicInit(&topic, TOPICID, NULL);

  // initialize nodes
  tutorialMasterInit(&master, URT_THREAD_PRIO_NORMAL_MAX, &triggerSource, TOPICID);
  tutorialSlaveInit(&slave, URT_THREAD_PRIO_NORMAL_MAX, TOPICID);

  // add shell command
  aosShellAddCommand(&shellcmd_message);
  aosShellAddCommand(&shellcmd_pubsub);

  return;
}
