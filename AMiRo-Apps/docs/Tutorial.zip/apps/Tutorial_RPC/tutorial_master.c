#include <tutorial.h>

#define TRIGGEREVENT (urtCoreGetEventMask() << 1)
#define SERVICEEVENT (urtCoreGetEventMask() << 2)

urt_osEventMask_t masterSetup(urt_node_t* node, void* master) {
  (void)node;
  urtEventRegister(((struct tutorial_master*)master)->trigger_source, &((struct tutorial_master*)master)->trigger_listener, TRIGGEREVENT, 0);
  return TRIGGEREVENT;
}

urt_osEventMask_t masterLoop(urt_node_t* node, urt_osEventMask_t event, void* master) {
  (void)node;

  // handle trigger events
  if (event & TRIGGEREVENT) {
    urt_osEventFlags_t flags = urtEventListenerClearFlags(&((struct tutorial_master*)master)->trigger_listener, ~0);

    // handle message trigger event
    if (flags & TRIGGERFLAG_MESSAGE) {
      urtPrintf("Hello World!\n");
    }

    // handle publish-subscribe trigger event
    if (flags & TRIGGERFLAG_PUBSUB) {
      urt_osTime_t t;
      urtTimeNow(&t);
      urtPrintf("Hello?\n");
      urtPublisherPublish(&((struct tutorial_master*)master)->publisher, NULL, 0, &t, URT_PUBLISHER_PUBLISH_DETERMINED);
    }

    // handle RPC trigger event
    if (flags & TRIGGERFLAG_RPC) {
      urtPrintf("Hello?\n");
      urt_service_t* service = urtCoreGetService(((struct tutorial_master*)master)->serviceid);
      urtNrtRequestAcquire(&((struct tutorial_master*)master)->request);
      urtNrtRequestSubmit(&((struct tutorial_master*)master)->request, service, 0, SERVICEEVENT);
    }
  }

  // handle service event
  if (event & SERVICEEVENT) {
    urtNrtRequestRetrieve(&((struct tutorial_master*)master)->request, URT_REQUEST_RETRIEVE_ENFORCING, NULL, NULL);
    urtPrintf(":)\n");
    urtNrtRequestRelease(&((struct tutorial_master*)master)->request);
  }

  return TRIGGEREVENT | SERVICEEVENT;
}

void masterShutdown(urt_node_t* node, urt_status_t reason, void* master) {
  (void)node;
  (void)reason;
  urtEventUnregister(((struct tutorial_master*)master)->trigger_source, &((struct tutorial_master*)master)->trigger_listener);
  return;
}

void tutorialMasterInit(struct tutorial_master* master, urt_osThreadPrio_t prio, urt_osEventSource_t* trigger, urt_topicid_t topicid, urt_serviceid_t serviceid) {
  // initialize node
  urtNodeInit(&master->node, (urt_osThread_t*)master->thread, sizeof(master->thread), prio,
              masterSetup, master,
              masterLoop, master,
              masterShutdown, master);

  // initialize event data
  master->trigger_source = trigger;
  urtEventListenerInit(&master->trigger_listener);

  // initialize publish-subscribe data
  urtPublisherInit(&master->publisher, urtCoreGetTopic(topicid));

  // initialize RPC data
  master->serviceid = serviceid;
  urtNrtRequestInit(&master->request, NULL);

  return;
}
