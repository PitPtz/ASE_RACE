#ifndef TUTORIAL_MASTER_H
#define TUTORIAL_MASTER_H

#include <tutorial.h>

#define STACKSIZE_MASTER 256

struct tutorial_master {
  URT_THREAD_MEMORY(thread, STACKSIZE_MASTER);
  urt_node_t node;
  urt_osEventSource_t* trigger_source;
  urt_osEventListener_t trigger_listener;
  urt_publisher_t publisher;
  urt_serviceid_t serviceid;
  urt_nrtrequest_t request;
};

void tutorialMasterInit(struct tutorial_master* master, urt_osThreadPrio_t prio, urt_osEventSource_t* trigger, urt_topicid_t topicid, urt_serviceid_t serviceid);

#endif
