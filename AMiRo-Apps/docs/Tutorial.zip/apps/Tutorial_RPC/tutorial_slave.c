#include <tutorial.h>

#define PUBLISHEVENT (urtCoreGetEventMask() << 1)
#define REQUESTEVENT (urtCoreGetEventMask() << 2)

urt_osEventMask_t slaveSetup(urt_node_t* node, void* slave) {
  (void)node;
  urt_topic_t* topic = urtCoreGetTopic(((struct tutorial_slave*)slave)->topicid);
  urtNrtSubscriberSubscribe(&((struct tutorial_slave*)slave)->subscriber, topic, PUBLISHEVENT);
  return PUBLISHEVENT | REQUESTEVENT;
}

urt_osEventMask_t slaveLoop(urt_node_t* node, urt_osEventMask_t event, void* slave) {
  (void)node;

  // handle publish event
  if (event & PUBLISHEVENT) {
    urtNrtSubscriberFetchLatest(&((struct tutorial_slave*)slave)->subscriber, NULL, NULL, NULL, NULL);
    urtPrintf("\tWorld!\n");
  }

  // handle request event
  if (event & REQUESTEVENT) {
    urt_service_dispatched_t dispatched;
    urtServiceDispatch(&((struct tutorial_slave*)slave)->service, &dispatched, NULL, NULL, NULL);
    urtPrintf("\tWorld!\n");
    urtServiceAcquireRequest(&((struct tutorial_slave*)slave)->service, &dispatched);
    urtServiceRespond(&dispatched, 0);
  }

  return PUBLISHEVENT | REQUESTEVENT;
}

void slaveShutdown(urt_node_t* node, urt_status_t reason, void* slave) {
  (void)node;
  (void)reason;
  urtNrtSubscriberUnsubscribe(&((struct tutorial_slave*)slave)->subscriber);
  return;
}

void tutorialSlaveInit(struct tutorial_slave* slave, urt_osThreadPrio_t prio, urt_topicid_t topicid, urt_serviceid_t serviceid) {
  // initialize node
  urtNodeInit(&slave->node, (urt_osThread_t*)slave->thread, sizeof(slave->thread), prio,
              slaveSetup, slave,
              slaveLoop, slave,
              slaveShutdown, slave);

  // initialize publish-subscribe data
  slave->topicid = topicid;
  urtNrtSubscriberInit(&slave->subscriber);

  // initialize RPC data
  urtServiceInit(&slave->service, serviceid, slave->node.thread, REQUESTEVENT);

  return;
}
