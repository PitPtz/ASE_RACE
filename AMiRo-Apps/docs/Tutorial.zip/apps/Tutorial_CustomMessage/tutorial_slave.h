#ifndef TUTORIAL_SLAVE_H
#define TUTORIAL_SLAVE_H

#include <tutorial.h>

#define STACKSIZE_SLAVE 256

struct tutorial_slave {
  URT_THREAD_MEMORY(thread, STACKSIZE_SLAVE);
  urt_node_t node;
  urt_topicid_t topicid;
  urt_nrtsubscriber_t subscriber;
  urt_service_t service;
  char message[PAYLOAD_SIZE];
};

void tutorialSlaveInit(struct tutorial_slave* slave, urt_osThreadPrio_t prio, urt_topicid_t topicid, urt_serviceid_t serviceid);

#endif
