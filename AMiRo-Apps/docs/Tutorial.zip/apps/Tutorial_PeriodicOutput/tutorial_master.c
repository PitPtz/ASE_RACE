#include <tutorial.h>

#define TRIGGEREVENT (urtCoreGetEventMask() << 1)

urt_osEventMask_t masterSetup(urt_node_t* node, void* master) {
  (void)node;
  urtEventRegister(((struct tutorial_master*)master)->trigger_source, &((struct tutorial_master*)master)->trigger_listener, TRIGGEREVENT, 0);
  return TRIGGEREVENT;
}

urt_osEventMask_t masterLoop(urt_node_t* node, urt_osEventMask_t event, void* master) {
  (void)node;

  // handle trigger events
  if (event & TRIGGEREVENT) {
    urt_osEventFlags_t flags = urtEventListenerClearFlags(&((struct tutorial_master*)master)->trigger_listener, ~0);

    // handle message trigger event
    if (flags & TRIGGERFLAG_MESSAGE) {
      urtPrintf("Hello World!\n");
    }
  }

  return TRIGGEREVENT;
}

void masterShutdown(urt_node_t* node, urt_status_t reason, void* master) {
  (void)node;
  (void)reason;
  urtEventUnregister(((struct tutorial_master*)master)->trigger_source, &((struct tutorial_master*)master)->trigger_listener);
  return;
}

void tutorialMasterInit(struct tutorial_master* master, urt_osThreadPrio_t prio, urt_osEventSource_t* trigger) {
  // initialize node
  urtNodeInit(&master->node, (urt_osThread_t*)master->thread, sizeof(master->thread), prio,
              masterSetup, master,
              masterLoop, master,
              masterShutdown, master);

  // initialize event data
  master->trigger_source = trigger;
  urtEventListenerInit(&master->trigger_listener);

  return;
}
