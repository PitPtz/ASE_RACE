#ifndef TUTORIAL_H
#define TUTORIAL_H

#include <urt.h>

#define TRIGGERFLAG_MESSAGE (1 << 0)

#include <tutorial_master.h>

#endif
