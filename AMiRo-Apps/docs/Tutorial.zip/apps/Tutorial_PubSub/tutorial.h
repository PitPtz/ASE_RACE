#ifndef TUTORIAL_H
#define TUTORIAL_H

#include <urt.h>

#define TRIGGERFLAG_MESSAGE (1 << 0)
#define TRIGGERFLAG_PUBSUB  (1 << 1)

#include <tutorial_master.h>
#include <tutorial_slave.h>

#endif
